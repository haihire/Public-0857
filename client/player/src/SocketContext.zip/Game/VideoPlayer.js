import { useEffect, useRef, useState } from "react";
import videojs from "video.js";
import axios from "axios";
import "./VideoPlayer.scss";
import { useStore } from "../store";
const VideoPlayer = ({ roomId, roomType }) => {
  const { sound } = useStore((state) => state);

  const videoRef = useRef(null);
  const ivsVideoRef = useRef(null);
  const playerRef = useRef(null);
  const stageRef = useRef(null);
  const [isLoading, setIsLoading] = useState(true);

  // 비디오 프레임 조정 함수

  // IVS 초기화
  const initializeStage = async (roomId) => {
    try {
      const response = await axios
        .post("https://ivs.pd-broadcast.com/cmd/stage/create-token", { roomId })
        .catch((error) => {
          console.log("Post Error:", error);
        });

      const token = response.data.token;

      const { Stage, StageEvents, SubscribeType } = window.IVSBroadcastClient;

      const strategy = {
        audioTrack: undefined,
        videoTrack: undefined,
        updateTracks(newAudioTrack, newVideoTrack) {
          this.audioTrack = newAudioTrack;
          this.videoTrack = newVideoTrack;
        },
        stageStreamsToPublish() {
          return [this.audioTrack, this.videoTrack].filter(Boolean);
        },
        shouldPublishParticipant() {
          return true;
        },
        shouldSubscribeToParticipant() {
          return SubscribeType.AUDIO_VIDEO;
        },
      };

      if (stageRef.current) {
        await stageRef.current.leave();
      }

      stageRef.current = new Stage(token, strategy);

      stageRef.current.on(
        StageEvents.STAGE_PARTICIPANT_STREAMS_ADDED,
        (participant, streams) => {
          const videoStream = streams.find(
            (stream) => stream.mediaStreamTrack.kind === "video"
          );
          if (videoStream && ivsVideoRef.current) {
            const mediaStream = new MediaStream();
            mediaStream.addTrack(videoStream.mediaStreamTrack);
            ivsVideoRef.current.srcObject = mediaStream;
            setIsLoading(false);
          }
        }
      );
      stageRef.current.on(StageEvents.ERROR, (error) => {
        console.error("Stage error:", error);
      });
      await stageRef.current.join();
    } catch (error) {
      console.warn("IVS 초기화 오류:", error);
      setIsLoading(false);
    } finally {
      setIsLoading(false);
    }
  };

  // Video.js 초기화
  const initializeVideoJS = (roomId) => {
    try {
      const player = (playerRef.current = videojs(videoRef.current, {
        controls: false,
        autoplay: false,
        preload: "auto",
        children: [],
      }));

      player.src({
        src: `wss://live.rlive-broadcast.com/Baccarat/${roomId}.webrtc`,
        iceServers: [{ urls: "stun:stun1.l.google.com:19302" }],
      });

      player.on("playing", () => {
        setIsLoading(false);
      });

      player.on("error", () => {});

      return player;
    } catch (error) {
      console.error("VideoJS 초기화 오류:", error);
    }
  };

  // 방 타입에 따라 플레이어 초기화
  useEffect(() => {
    if (!roomId || !roomType) return;
    const loadIVSScript = () => {
      return new Promise((resolve) => {
        if (window.IVSBroadcastClient) return resolve();

        const script = document.createElement("script");
        script.src =
          "https://web-broadcast.live-video.net/1.6.0/amazon-ivs-web-broadcast.js";
        script.onload = resolve;
        document.body.appendChild(script);
      });
    };

    const initPlayer = async () => {
      if (roomType === "ivs") {
        await loadIVSScript();
        initializeStage(roomId);
      } else if (roomType === "ant") {
        initializeVideoJS(roomId);
      }
    };

    initPlayer();

    return () => {
      if (playerRef.current) {
        playerRef.current.dispose();
      }
      if (stageRef.current) {
        stageRef.current.leave();
      }
    };
  }, [roomId, roomType]);

  return (
    <div
      className="video-js vjs-default-skin vjs-paused vjs-controls-disabled vjs-workinghover vjs-v7 vjs-user-active videojs-webrtc-plugin"
      tabIndex="-1"
      translate="no"
      aria-label="Video Player"
      style={{
        width: "100%",
        height: "100%",
      }}
    >
      {isLoading && (
        <div
          className="loading-box"
          id="loading-box"
          style={{ backgroundColor: "black" }}
        >
          <div className="loadingTest"></div>
        </div>
      )}

      <video
        ref={videoRef}
        className="video-js"
        autoPlay
        loop
        disablePictureInPicture
        muted={!sound}
        playsInline
        webkit-playsinline=""
        controls={false}
        style={{
          position: "absolute",
          width: "100%",
          height: "100%",
        }}
      />

      <video
        ref={ivsVideoRef}
        className="vjs-tech"
        autoPlay
        loop
        disablePictureInPicture
        muted={!sound}
        playsInline
        webkit-playsinline=""
        style={{
          width: "100%",
          height: "100%",
        }}
      />
    </div>
  );
};

export default VideoPlayer;
